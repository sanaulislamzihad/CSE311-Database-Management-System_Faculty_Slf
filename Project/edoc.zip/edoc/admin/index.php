<?php
session_start();

if(isset($_SESSION["user"])){
    if(($_SESSION["user"])=="" or $_SESSION['usertype']!='a'){
        header("location: ../login.php");
    } else {
        // Redirect to doctors page as default admin page
        header("location: doctors.php");
    }
} else {
    header("location: ../login.php");
}
?>
