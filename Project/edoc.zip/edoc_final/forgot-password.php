<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="css/animations.css">  
    <link rel="stylesheet" href="css/main.css">  
    <link rel="stylesheet" href="css/index.css">
    <link rel="stylesheet" href="css/login.css">
    <title>Forgot Password</title>
</head>
<body class="d-flex flex-column" style="min-height: 100vh; padding-top: 70px;">
    <nav class="navbar navbar-expand-lg navbar-light fixed-top">
        <div class="container">
            <a class="navbar-brand" href="index.html">
                <i class="bi bi-heart-pulse-fill"></i> eDoc
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="login.php">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link btn btn-outline-light rounded-pill px-4 ms-2" href="signup.php">Register</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <?php
    //  AUTHENTICATION & SECURITY - PASSWORD RESET SYSTEM SECTION START 
    session_start();
    date_default_timezone_set('Asia/Dhaka');
    include("connection.php");
    include("includes/auth-helper.php");

    $error='<div class="alert alert-info text-center" style="display:none;"></div>';

    if($_POST){
        //  DATABASE RELATIONS USED: WebUser, Password_Reset_Tokens 
        // WebUser: Verify email exists in system
        // Password_Reset_Tokens: Generate and store reset token with expiration
        //  PASSWORD RESET TOKEN GENERATION START 
        $email=$_POST['useremail'];
        $result= $database->query("select * from webuser where email='$email'");
        if($result->num_rows==1){
            $token = bin2hex(random_bytes(32));
            $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));
            $database->query("INSERT INTO password_reset_tokens (email, token, expires_at) VALUES ('$email', '$token', '$expires') ON DUPLICATE KEY UPDATE token='$token', expires_at='$expires', used=0");
            $error='<div class="alert alert-success text-center">Reset link sent! Check your email. (Token: '.$token.' - Remove this in production)</div>';
        } else {
            $error='<div class="alert alert-danger text-center">Email not found in our system.</div>';
        }
        //  PASSWORD RESET TOKEN GENERATION END 
    }
    ?>

    <!--  PASSWORD RESET FORM SECTION START  -->
    <div class="d-flex justify-content-center align-items-center flex-grow-1 w-100 px-3">
        <div class="w-100" style="max-width: 500px;">
            <div class="card shadow-lg">
                <div class="card-body p-5">
                    <h2 class="card-title text-center mb-4">Forgot Password?</h2>
                    <p class="text-center text-muted mb-4">Enter your email to reset password</p>
                    <form action="" method="POST" class="needs-validation" novalidate>
                        <?php echo $error; ?>
                        <div class="mb-3">
                            <label for="useremail" class="form-label">Email:</label>
                            <input type="email" name="useremail" class="form-control" placeholder="Email Address" required>
                        </div>
                        <button type="submit" class="btn btn-primary w-100 mb-3">Send Reset Link</button>
                    </form>
                    <div class="text-center">
                        <p class="mb-0"><small>Remember your password? <a href="login.php" class="text-decoration-none">Login</a></small></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--  PASSWORD RESET FORM SECTION END  -->
    <!--  AUTHENTICATION & SECURITY - PASSWORD RESET SYSTEM SECTION END  -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

