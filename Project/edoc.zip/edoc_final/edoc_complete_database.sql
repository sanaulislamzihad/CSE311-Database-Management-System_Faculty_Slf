-- Healthcare Appointment & Prescription Tracking System
-- Create database if not exists
CREATE DATABASE IF NOT EXISTS edoc;
USE edoc;


-- Admin table
DROP TABLE IF EXISTS admin;
CREATE TABLE admin (
  aemail VARCHAR(255) NOT NULL,
  apassword VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY (aemail)
);

-- Patient table
DROP TABLE IF EXISTS patient;
CREATE TABLE patient (
  pid INT(11) NOT NULL AUTO_INCREMENT,
  pemail VARCHAR(255) DEFAULT NULL,
  pname VARCHAR(255) DEFAULT NULL,
  ppassword VARCHAR(255) DEFAULT NULL,
  paddress VARCHAR(255) DEFAULT NULL,
  pnic VARCHAR(15) DEFAULT NULL,
  pdob DATE DEFAULT NULL,
  ptel VARCHAR(15) DEFAULT NULL,
  allergies TEXT,
  primary_doctor_id INT,
  location VARCHAR(255),
  PRIMARY KEY (pid)
);

-- Doctor table
DROP TABLE IF EXISTS doctor;
CREATE TABLE doctor (
  docid INT(11) NOT NULL AUTO_INCREMENT,
  docemail VARCHAR(255) DEFAULT NULL,
  docname VARCHAR(255) DEFAULT NULL,
  docpassword VARCHAR(255) DEFAULT NULL,
  docnic VARCHAR(15) DEFAULT NULL,
  doctel VARCHAR(15) DEFAULT NULL,
  specialties INT(2) DEFAULT NULL,
  location VARCHAR(255),
  availability_status VARCHAR(50) DEFAULT 'available',
  PRIMARY KEY (docid),
  KEY specialties (specialties)
);

-- Schedule table
DROP TABLE IF EXISTS schedule;
CREATE TABLE schedule (
  scheduleid INT(11) NOT NULL AUTO_INCREMENT,
  docid VARCHAR(255) DEFAULT NULL,
  title VARCHAR(255) DEFAULT NULL,
  scheduledate DATE DEFAULT NULL,
  scheduletime TIME DEFAULT NULL,
  nop INT(4) DEFAULT NULL,
  PRIMARY KEY (scheduleid),
  KEY docid (docid)
);

-- Appointment table
DROP TABLE IF EXISTS appointment;
CREATE TABLE appointment (
  appoid INT(11) NOT NULL AUTO_INCREMENT,
  pid INT(10) DEFAULT NULL,
  apponum INT(3) DEFAULT NULL,
  scheduleid INT(10) DEFAULT NULL,
  appodate DATE DEFAULT NULL,
  status VARCHAR(50) DEFAULT 'pending',
  reminder_sent BOOLEAN DEFAULT FALSE,
  notes TEXT,
  PRIMARY KEY (appoid),
  KEY pid (pid),
  KEY scheduleid (scheduleid)
);

-- Specialties table
DROP TABLE IF EXISTS specialties;
CREATE TABLE specialties (
  id INT(2) NOT NULL,
  sname VARCHAR(50) DEFAULT NULL,
  PRIMARY KEY (id)
);

-- WebUser table (for authentication)
DROP TABLE IF EXISTS webuser;
CREATE TABLE webuser (
  email VARCHAR(255) NOT NULL,
  usertype CHAR(1) DEFAULT NULL,
  PRIMARY KEY (email)
);

-- Prescriptions table
DROP TABLE IF EXISTS prescriptions;
CREATE TABLE prescriptions (
  prescription_id INT PRIMARY KEY AUTO_INCREMENT,
  appointment_id INT,
  doctor_id INT,
  patient_id INT,
  prescription_date DATE,
  diagnosis TEXT,
  follow_up_date DATE,
  follow_up_instructions TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Medicines table
DROP TABLE IF EXISTS medicines;
CREATE TABLE medicines (
  medicine_id INT PRIMARY KEY AUTO_INCREMENT,
  medicine_name VARCHAR(255),
  generic_name VARCHAR(255),
  dosage_form VARCHAR(50),
  strength VARCHAR(50),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Prescription Medicines (Many-to-Many relationship)
DROP TABLE IF EXISTS prescription_medicines;
CREATE TABLE prescription_medicines (
  id INT PRIMARY KEY AUTO_INCREMENT,
  prescription_id INT,
  medicine_id INT,
  dosage VARCHAR(100),
  frequency VARCHAR(100),
  duration VARCHAR(100),
  instructions TEXT
);

-- Medical History table
DROP TABLE IF EXISTS medical_history;
CREATE TABLE medical_history (
  history_id INT PRIMARY KEY AUTO_INCREMENT,
  patient_id INT,
  condition_name VARCHAR(255),
  diagnosis_date DATE,
  status VARCHAR(50),
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Visit Summaries table
DROP TABLE IF EXISTS visit_summaries;
CREATE TABLE visit_summaries (
  summary_id INT PRIMARY KEY AUTO_INCREMENT,
  appointment_id INT,
  chief_complaint TEXT,
  examination_findings TEXT,
  diagnosis TEXT,
  treatment_plan TEXT,
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (appointment_id) REFERENCES appointment(appoid) ON DELETE CASCADE
);

-- Add index for better performance
CREATE INDEX idx_appointment_id ON visit_summaries(appointment_id);

-- Password Reset Tokens table
DROP TABLE IF EXISTS password_reset_tokens;
CREATE TABLE password_reset_tokens (
  token_id INT PRIMARY KEY AUTO_INCREMENT,
  email VARCHAR(255),
  token VARCHAR(255),
  expires_at TIMESTAMP,
  used BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Admin data
INSERT INTO admin (aemail, apassword) VALUES
('admin@edoc.com', '123');

-- Patient data
INSERT INTO patient (pid, pemail, pname, ppassword, paddress, pnic, pdob, ptel) VALUES
(1, 'patient@edoc.com', 'Test Patient', '123', 'Sri Lanka', '0000000000', '2000-01-01', '0120000000'),
(2, 'emhashenudara@gmail.com', 'Hashen Udara', '123', 'Sri Lanka', '0110000000', '2022-06-03', '0700000000');

-- Doctor data
INSERT INTO doctor (docid, docemail, docname, docpassword, docnic, doctel, specialties) VALUES
(1, 'doctor@edoc.com', 'Test Doctor', '123', '000000000', '0110000000', 1);

-- Schedule data
INSERT INTO schedule (scheduleid, docid, title, scheduledate, scheduletime, nop) VALUES
(1, '1', 'Test Session', '2050-01-01', '18:00:00', 50),
(2, '1', 'Morning Session', '2022-06-10', '20:36:00', 1),
(3, '1', 'Evening Session', '2022-06-10', '20:33:00', 1);

-- Appointment data
INSERT INTO appointment (appoid, pid, apponum, scheduleid, appodate) VALUES
(1, 1, 1, 1, '2022-06-03');

-- Specialties data
INSERT INTO specialties (id, sname) VALUES
(1, 'Accident and emergency medicine'),
(2, 'Allergology'),
(3, 'Anaesthetics'),
(4, 'Biological hematology'),
(5, 'Cardiology'),
(6, 'Child psychiatry'),
(7, 'Clinical biology'),
(8, 'Clinical chemistry'),
(9, 'Clinical neurophysiology'),
(10, 'Clinical radiology'),
(11, 'Dental, oral and maxillo-facial surgery'),
(12, 'Dermato-venerology'),
(13, 'Dermatology'),
(14, 'Endocrinology'),
(15, 'Gastro-enterologic surgery'),
(16, 'Gastroenterology'),
(17, 'General hematology'),
(18, 'General Practice'),
(19, 'General surgery'),
(20, 'Geriatrics'),
(21, 'Immunology'),
(22, 'Infectious diseases'),
(23, 'Internal medicine'),
(24, 'Laboratory medicine'),
(25, 'Maxillo-facial surgery'),
(26, 'Microbiology'),
(27, 'Nephrology'),
(28, 'Neuro-psychiatry'),
(29, 'Neurology'),
(30, 'Neurosurgery'),
(31, 'Nuclear medicine'),
(32, 'Obstetrics and gynecology'),
(33, 'Occupational medicine'),
(34, 'Ophthalmology'),
(35, 'Orthopaedics'),
(36, 'Otorhinolaryngology'),
(37, 'Paediatric surgery'),
(38, 'Paediatrics'),
(39, 'Pathology'),
(40, 'Pharmacology'),
(41, 'Physical medicine and rehabilitation'),
(42, 'Plastic surgery'),
(43, 'Podiatric Medicine'),
(44, 'Podiatric Surgery'),
(45, 'Psychiatry'),
(46, 'Public health and Preventive Medicine'),
(47, 'Radiology'),
(48, 'Radiotherapy'),
(49, 'Respiratory medicine'),
(50, 'Rheumatology'),
(51, 'Stomatology'),
(52, 'Thoracic surgery'),
(53, 'Tropical medicine'),
(54, 'Urology'),
(55, 'Vascular surgery'),
(56, 'Venereology');

-- WebUser data
INSERT INTO webuser (email, usertype) VALUES
('admin@edoc.com', 'a'),
('doctor@edoc.com', 'd'),
('patient@edoc.com', 'p'),
('emhashenudara@gmail.com', 'p');

-- Sample medicines
INSERT INTO medicines (medicine_name, generic_name, dosage_form, strength) VALUES
('Paracetamol', 'Acetaminophen', 'Tablet', '500mg'),
('Amoxicillin', 'Amoxicillin', 'Capsule', '250mg'),
('Ibuprofen', 'Ibuprofen', 'Tablet', '400mg'),
('Cetirizine', 'Cetirizine', 'Tablet', '10mg'),
('Omeprazole', 'Omeprazole', 'Capsule', '20mg');

